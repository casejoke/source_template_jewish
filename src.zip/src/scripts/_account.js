var account = {
	init:function() {
		account.initVisualBlock();
	},
	initVisualBlock:function(){
		 $('.price-table--empty').each(function() {
		 //	var height_block = $(this).parent().next().find('.price-table').outerHeight();
		 //console.log(height_block);
		 //	$(this).height(height_block);
		 });
	}
};